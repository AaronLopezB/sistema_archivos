<?php

namespace App\Http\Controllers;

use App\Exports\ErroresExport;
use Cookie;
use DB;
use Excel;
use Illuminate\Http\Request;

class CobranzaHomeController extends Controller
{

    public function admin(Request $request)
    {

        return view('admin');
    }

    public function insert_serfin()
    {

        $date = date('Ymd');
        $file = "SE00360C" . $date . '.xls';
        $hmt  = $this->insert_serfin_hmt($file);
        $hmi  = $this->insert_inscripciones($file);
        $res  = ['hmt' => $hmt, 'hmi' => $hmi];
        return response()->json($res);
    }

    public function insert_serfin_hmt()
    {
        $date  = date('Ymd');
        $file  = "SE00360C" . $date . '.xls';
        $datos = DB::connection('hometravel')->table('pagos')
            ->join('origen', 'pagos.id', '=', 'origen.pago_id')
            ->join('stdr_respuestas', 'origen.clave', '=', 'stdr_respuestas.clave')
            ->whereRaw('SUBSTRING(origen.sys_key, 1,3) = ?', 'hmt')
            ->where('origen.archivo', $file)
            ->where('pagos.estatus', '<>', 'Pagado')
            ->select('pagos.paquete_id', 'origen.pago_id', DB::raw('case origen.clave when 0 then "Pagado" else "Rechazado" end as resultado'), 'origen.importe as cantidad', DB::raw('now() as created'), DB::raw('STR_TO_DATE(origen.fecha, "%Y%m%d") as fecha_de_respuesta'), DB::raw('concat(" ", origen.archivo, ":", stdr_respuestas.rest_1) as motivo_del_rechazo'))
            ->get();

        if (count($datos) > 0) {
            $cont = 0;
            foreach ($datos as $key) {
                $serfin[] = [
                    'contrato_id'        => $key->paquete_id,
                    'pago_id'            => $key->pago_id,
                    'resultado'          => $key->resultado,
                    'cantidad'           => $key->cantidad,
                    'created'            => $key->created,
                    'fecha_de_respuesta' => $key->fecha_de_respuesta,
                    'motivo_del_rechazo' => $key->motivo_del_rechazo,
                ];
                $cont += 1;
            }
            Cookie::queue('hmt', $cont, env('TIME_COOKIE'));
            if (count($serfin) > 5000) {
                foreach (array_chunk($serfin, 3000) as $insert) {
                    $result = DB::connection('hometravel')->table('serfinrespuestas')->insert($insert);
                }
            } else {
                $result = DB::connection('hometravel')->table('serfinrespuestas')->insert($serfin);
            }

            if ($result != true) {
                return response()->json(['estatus' => false]);
            }
            return response()->json(['estatus' => true, 'registros' => $cont]);
        } else {
            return false;
        }
    }

    public function insert_inscripciones()
    {
        $date  = date('Ymd');
        $file  = "SE00360C" . $date . '.xls';
        $datos = DB::connection('hometravel')->table('inscripciones')
            ->join('origen', 'inscripciones.id', '=', 'origen.pago_id')
            ->join('stdr_respuestas', 'origen.clave', '=', 'stdr_respuestas.clave')
            ->whereRaw('SUBSTRING(origen.sys_key, 1,3) = ?', 'hmi')
            ->where('origen.archivo', $file)
            ->where('inscripciones.estatus', '<>', 'Pagado')
            ->select('inscripciones.id', 'origen.pago_id', DB::raw('case origen.clave when 0 then "Pagado" else "Rechazado" end as resultado'), 'origen.importe as cantidad', DB::raw('now() as created'), DB::raw('STR_TO_DATE(origen.fecha, "%Y%m%d") as fecha_de_respuesta'), DB::raw('concat(" ", origen.archivo, ":", stdr_respuestas.rest_1) as motivo_del_rechazo'))
            ->get();
        if (count($datos) != 0) {
            $cont = 0;
            foreach ($datos as $key) {
                $serfin[] = [
                    'contrato_id'        => $key->id,
                    'pago_id'            => $key->pago_id,
                    'resultado'          => $key->resultado,
                    'cantidad'           => $key->cantidad,
                    'created'            => $key->created,
                    'fecha_de_respuesta' => $key->fecha_de_respuesta,
                    'motivo_del_rechazo' => $key->motivo_del_rechazo,
                ];
                $cont += 1;
            }

            Cookie::queue('hmi', $cont, env('TIME_COOKIE'));
            $result = DB::connection('hometravel')->table('serfinrespuestasinscripciones')->insert($serfin);
            if ($result != true) {
                return response()->json(['estatus' => false]);
            }
            return response()->json(['estatus' => true, 'registros' => $cont]);
        } else {
            return response()->json(['estatus' => false, 'mensaje' => 'No se encontraron registros de inscripciones']);

        }
    }

    public function update_serfin_hmt()
    {
        $date  = date('Ymd');
        $file2 = "SE00360C" . $date . '.xls';
        $datos = DB::connection('hometravel')->table('pagos')
            ->join('origen', 'pagos.id', '=', 'origen.pago_id')
            ->join('stdr_respuestas', 'origen.clave', '=', 'stdr_respuestas.clave')
            ->where('origen.archivo', $file2)
            ->where('pagos.estatus', '<>', 'Pagado')
            ->whereRaw('SUBSTRING(origen.sys_key, 1,3) = ?', 'hmt')
            ->update(
                [
                    'pagos.estatus'                => DB::raw('case origen.clave when 0 then "Pagado" else "Rechazado" end'),
                    //'pagos.cantidad'               => 'origen.importe',
                    'pagos.fecha_de_pago'          => DB::raw('STR_TO_DATE(origen.fecha, "%Y%m%d")'),
                    'pagos.pagado_desde_santander' => DB::raw('case origen.clave when 1 then 0 else 1 end'),
                    'pagos.modified'               => DB::raw('now()'),
                ]
            );

        Cookie::queue('hmt_update', $datos, env('TIME_COOKIE'));
        Cookie::queue('res2', true, env('TIME_COOKIE'));
        return response()->json(['estatus' => true, 'registros' => $datos]);
    }

    public function update_inscripciones()
    {
        $date  = date('Ymd');
        $file2 = "SE00360C" . $date . '.xls';
        $datos = DB::connection('hometravel')->table('inscripciones')
            ->join('origen', 'inscripciones.id', '=', 'origen.pago_id')
            ->join('stdr_respuestas', 'origen.clave', '=', 'stdr_respuestas.clave')
            ->join('users', 'inscripciones.user_id', '=', 'users.id')
            ->where('origen.archivo', $file2)
            ->where('inscripciones.estatus', '<>', 'Pagado')
            ->whereRaw('SUBSTRING(origen.sys_key, 1,3) = ?', 'hmi')
            ->update(
                [
                    'inscripciones.estatus'  => DB::raw('case origen.clave when 0 then "Pagado" else "Rechazado" end'),
                    'inscripciones.modified' => DB::raw('now()'),
                    'inscripciones.estatus'  => 'Pagado',
                    'users.pago_inscripcion' => '1',
                    'users.tipo_asociado'    => '1',
                ]
            );
        if ($datos != 0) {
            $res = DB::connection('hometravel')->table('inscripciones')->where('modified', 'like', '%' . date('Y-m-d') . '%')->get();

            Cookie::queue('hmi_update', count($res), env('TIME_COOKIE'));
            return response()->json(['estatus' => true, 'registros' => count($res)]);
        }
        return response()->json(['estatus' => false, 'registros' => $datos]);
    }

    public function delete_origen()
    {
        $date  = date('Ymd');
        $file2 = "SE00360C" . $date . '.xls';
        $res   = DB::connection('hometravel')->delete('delete from origen where archivo = ?', [$file2]);
        if ($res > 0) {
            return response()->json(['estatus' => true, 'registros' => $res]);
        }

        return response()->json(['estatus' => false]);
    }
    public function consultar_errores()
    {
        $date = date('Ymd');
        // $file = "SE00360C" . $date . '.xls';
        $file = 'SE00360C20200703.xls';
        $res  = DB::connection('hometravel')->table('origen')
            ->select('pagos.paquete_id as contrato_id', 'origen.pago_id', 'origen.pago_segmento as segmento_archivo', 'origen.cliente', 'origen.importe as importe_cobrado_santander', 'origen.clave as clave_archivo_santander', DB::raw('CONCAT("CANTIDAD COBRADA EN EL ARCHIVO: ", serfinrespuestas.motivo_del_rechazo, " POR ", serfinrespuestas.cantidad) AS cobrado_en_archivo'), 'serfinrespuestas.resultado')
            ->join('pagos', 'origen.pago_id', '=', 'pagos.id')
            ->join('serfinrespuestas', 'origen.pago_id', '=', 'serfinrespuestas.pago_id')
            ->where('archivo', $file)
            ->whereIn('pagos.estatus', ['Pagado'])
            ->groupBy('origen.pago_id')
            ->orderBy('pagos.estatus', 'ASC')
            ->get();
        return $res;
    }

    public function errores()
    {
        $res = $this->consultar_errores();
        if (count($res) > 0) {
            return response()->json(['estatus' => true, 'registros' => count($res)]);
        }
        return response()->json(['estatus' => false]);
    }

    public function download_errores()
    {
        $res = $this->consultar_errores();
        return Excel::download(new ErroresExport($res), 'Errores-' . date('Ymd') . '.xls');
    }

    public function datos_cookies()
    {
        $hmt                = Cookie::get('hmt');
        $hmi                = Cookie::get('hmi');
        $hmt_update         = Cookie::get('hmt_update');
        $hmi_update         = Cookie::get('hmi_update');
        $origen_pacific     = Cookie::get('origen_pacific');
        $origen_home        = Cookie::get('origen_home');
        $srf_pacific        = Cookie::get('srf_pacific');
        $srf_pacific_update = Cookie::get('srf_pacific_update');
        $origen_i           = Cookie::get('origen_i');
        $res1               = Cookie::get('res1');
        $res2               = Cookie::get('res2');

        return response()->json(
            [
                'hmi'                => $hmi,
                'hmt'                => $hmt,
                'hmi_update'         => $hmi_update,
                'hmt_update'         => $hmt_update,
                'origen_pacific'     => $origen_pacific,
                'origen_home'        => $origen_home,
                'srf_pacific'        => $srf_pacific,
                'srf_pacific_update' => $srf_pacific_update,
                'origen_i'           => $origen_i,
                'res1'               => $res1,
                'res2'               => $res2,
            ]
        );
    }
}
