<?php

namespace App\Http\Controllers;

use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Log;

class AuthController extends Controller
{
    public function login(Request $request)
    {
        $username = $request->email;
        $password = base64_encode($request->password);
        $result   = User::where('username', $username)->where('clave', $password)->first();
        // dd($result);
        if ($result) {
            $datos = [
                'nombre' => $result->nombre . ' ' . $result->apellidos,
                'role'   => $result->role,
                'activo' => true,
            ];
            session()->put($datos);
            $date = Carbon::now();
            Log::info('Usuario logeado: ' . $datos['nombre'] . '(' . $result->username . ') ' . $date);
            return redirect()->route('admin');
        }

        return redirect()->route('login')->with(['estatus' => 'Usuario no valido!']);
    }

    public function logout(Request $request)
    {
        session()->forget('activo');
        return redirect()->route('login');
    }
}
