<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Serfinrespuestas extends Model
{
    protected $table = 'serfinrespuestas';
}
