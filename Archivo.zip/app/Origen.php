<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Origen extends Model
{

    protected $table    = 'origen';
    public $timestamps  = false;
    protected $fillable = [
        'importe',
        'fecha',
        'banco',
        'tarjeta',
        'sys_key',
        'pago_id',
        'pago_segmento',
        'cliente',
        'clave',
        'archivo',
    ];
}
